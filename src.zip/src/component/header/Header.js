import React from 'react';
import '../header/Header.css';
import { PiListBold } from "react-icons/pi";
function Header() {
    return (
        <>
            <header className='header-container'>
                <div className='headerstops'>
                    <div className='logoManulist'>
                        <h3>AdminDashboard</h3>
                        <PiListBold /></div>
                </div>
            </header>
        </>
    );
}
export default Header;