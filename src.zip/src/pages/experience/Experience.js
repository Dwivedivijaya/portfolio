import React from 'react';

export default function Experience() {
  // Array of experience data
  const experiences = [
    {
      company: "1.Innefu Labs Pvt Ltd, New Delhi (Dec 2023 – Present)",
      client: "DRDO OFFICE",
      role: "UI Developer",
      environment: "React, JavaScript, Bootstrap, CSS3, HTML5, Material UI and Visualstudio.",
      responsibilities: [
        "Create interactive and responsive web pages using React.js.",
        "Use React’s built-in performance tools to monitor and optimize rendering performance.",
        "Debug, troubleshoot, and resolve issues in existing React applications.",
        "Maintain documentation for any third-party libraries or custom tools used in the application.",
        "Use React’s state management (local state, context, or Redux) to manage the application’s data flow.",
        "Implement lazy loading, code splitting, and other optimization techniques to improve load times and user experience.",
        "Collaborate with backend developers to integrate APIs using tools like fetch, axios, and GraphQL.",
        "Implement form validation, manage form state, and handle form submission with React-controlled components."
      ]
    },
    {
      company: "2.Provab TechnoSoft, Bangalore (Dec 2021 – 14 July 2023)",
      role: "UI Developer",
      environment: "React, HTML5, CSS3, JavaScript, Tailwind CSS, JQuery, Photoshop, WordPress.",
      responsibilities: [
        "Implement UI designs using web technologies such as HTML, CSS, Bootstrap, Photoshop, React, and JavaScript. Ensure cross-browser compatibility and responsiveness of the user interface.",
        "Handle multiple design projects simultaneously, often working under tight deadlines.",
        "Collaborated with teammates to deliver valuable features meeting business and customer needs.",
        "Document the UI development process, codebase, and any relevant information for future reference and team collaboration.",
        "PSD to HTML Conversion.",
        "Document bug reports, tickets, and any code changes.",
        "Optimize images, graphics, and other design elements to ensure fast loading times and smooth performance.",
        "Design and implement themes or templates for content management systems (WordPress) that are easy to use and customizable."
      ]
    },
    {
      company: "3.Foiwe Info Global Solution, Bangalore (April 2019 – 24 Dec 2019)",
      role: "System Analysis",
      environment: "HTML5, CSS3, JavaScript, Bootstrap, JQuery, Sublime and Visualstudio.",
      responsibilities: [
        "Design and manage style guidelines between mobile & desktop.",
        "Document bug reports, tickets, and any code changes.",
        "Create interactive and responsive web pages using Bootstrap framework.",
        "Design the overall look and feel of websites, ensuring they align with the brand’s identity and objectives.",
        "Ensure that websites are fully responsive and work seamlessly across different devices (desktops, tablets, smartphones).",
        "Test and resolve any design issues across different browsers to provide a consistent experience for all users."
      ]
    },
    {
      company: "4.Dezven Software Solution (July 2018 – Dec 2018)",
      role: "Web Designer Intern",
      environment: "HTML5, CSS3, JavaScript, Bootstrap, JQuery, Sublime and Visualstudio.",
      description: "I worked a 6-month internship as a Web Designer."
    }
  ];

  return (
    <>
      <section id="Experience" className="Experience section ed">
        <div className="section-title aos-init aos-animate" data-aos="fade-up">
          <h2 className="EducationAbouts">Experience (4YRS)</h2>
        </div>
        <div>
          {experiences.map((experience, index) => (
            <div key={index} className="ExperienceprojectsUI">
              <ul className="Experienceprojects">
                <li>
                  <strong className="headerprojects">{experience.company}</strong>
                </li>
                {experience.client && (
                  <li>
                    <strong>Client:</strong> <span>{experience.client}</span>
                  </li>
                )}
                <li>
                  <strong>Role:</strong> <span>{experience.role}</span>
                </li>
                <li>
                  <strong>Environment:</strong> <span>{experience.environment}</span>
                </li>
                {experience.description && (
                  <li>
                    <strong>Description:</strong> <span>{experience.description}</span>
                  </li>
                )}
              </ul>
              {experience.responsibilities && (
                <ul className="Experienceprojectslist">
                  {experience.responsibilities.map((responsibility, idx) => (
                    <li key={idx}><span>{responsibility}</span></li>
                  ))}
                </ul>
              )}
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
