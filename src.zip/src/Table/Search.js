import React from 'react';
import { MdDelete } from "react-icons/md";
import { IoSearch } from "react-icons/io5";

function Search() {
    return (
        <>
            <div className='tablesflex d-flex align-items justify-content-between'>
            <div className='d-flex align-items gap-2'>
              <input type="text" className="form-control1 " placeholder='Search' />
              <span className=''>
                <IoSearch  />
              </span>
            </div>
            <MdDelete />
          </div>
        </>
    );
}

export default Search;
