import React from 'react'
import { MdArrowForwardIos } from "react-icons/md";
export default function Eduction() {
    return (
        <>
            <section id="eduction" className="about section ed">
                <div className="section-title aos-init aos-animate" data-aos="fade-up">
                    <h2 className='EducationAbouts'>Education</h2>
                </div>
                <ul className='mb-0 pb-0'>
                    <li><MdArrowForwardIos /> <span> Bachelor’sfrom “TIT Collage Bhopal (2018)
                    </span></li>
                    <li><MdArrowForwardIos /> <span> HSS from “State Board M.P (2014)
                    </span></li>
                    <li className='mb-0 pb-0'><MdArrowForwardIos /> <span> SSC from “State Board M.P (2012)
                    </span></li>

                </ul>
            </section>
        </>
    )
}
