import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Link as ScrollLink } from 'react-scroll';
import { FaGithub } from "react-icons/fa6";
import { FaLinkedin } from "react-icons/fa6";
import { BiLogoNetlify } from "react-icons/bi";
import { FaHome } from "react-icons/fa";
import { MdCastForEducation } from "react-icons/md";
import { FaRegUser } from "react-icons/fa";
import { GiSkills } from "react-icons/gi";
import { RiLink } from "react-icons/ri";
import { SiMusicbrainz } from "react-icons/si";
import Profiles2 from '../../assets/images/profiles2.jpeg';

function Manusidebar() {
  const [activeLink, setActiveLink] = useState('hero');

  // const navItems = [
  //   { to: 'hero', label: 'Home', icon: <FaHome className='navicon' /> },
  //   { to: 'about', label: 'About', icon: <FaRegUser className='navicon' /> },
  //   { to: 'eduction', label: 'Eduction', icon: <MdCastForEducation className='navicon' /> },
  //   { to: 'skills', label: 'Skills', icon: <GiSkills className='navicon' /> },
  //   { to: 'Experience', label: 'Experience', icon: <SiMusicbrainz className='navicon' /> },
  //   { to: 'projectlinks', label: 'Project', icon: <RiLink className='navicon' /> },
  // ];
   const handleSetActive = (link) => {
    setActiveLink(link);
  };
  return (
    <div className='sidebarManus dark-background d-flex flex-column'>
      <div className="profile-img">
        <img src={Profiles2} alt="Profile" className="img-fluid rounded-circle" />
      </div>
      <Link className="logo d-flex align-items-center justify-content-center">
        <h1 className="sitename">Vijaya Dwivedi</h1>
      </Link>
      <div className="social-links text-center">
        <Link to="https://github.com/Dwivedivijaya/" className="github" data-bs-toggle="tooltip" data-bs-placement="bottom" title="github">
          <FaGithub />
        </Link>
        <Link to="https://www.linkedin.com/in/immediate-joiner-vijaya-dwivedi-69a59b14a/" className="facebook" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Linkedin">
          <FaLinkedin />
        </Link>
        <Link to="https://www.netlify.com/" className="instagram" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Netlify">
          <BiLogoNetlify />
        </Link>
      </div>

      <nav className='navmenu'>
      <ul>
        <li>
          <ScrollLink
            to="hero"
            smooth={true}
            duration={500}
            className={`github ${activeLink === 'hero' ? 'active' : ''}`}
            onSetActive={() => handleSetActive('hero')}
          >
            <FaHome className="navicon" />Home
          </ScrollLink>
        </li>
        <li>
          <ScrollLink
            to="about"
            smooth={true}
            duration={500}
            className={`github ${activeLink === 'about' ? 'active' : ''}`}
            onSetActive={() => handleSetActive('about')}
          >
            <FaRegUser className="navicon" />About
          </ScrollLink>
        </li>
        <li>
          <ScrollLink
            to="eduction"
            smooth={true}
            duration={500}
            className={`github ${activeLink === 'education' ? 'active' : ''}`}
            onSetActive={() => handleSetActive('education')}
          >
            <MdCastForEducation className="navicon" />Education
          </ScrollLink>
        </li>
        <li>
          <ScrollLink
            to="skills"
            smooth={true}
            duration={500}
            className={`github ${activeLink === 'skills' ? 'active' : ''}`}
            onSetActive={() => handleSetActive('skills')}
          >
            <GiSkills className="navicon" />Skills
          </ScrollLink>
        </li>
        <li>
          <ScrollLink
            to="Experience"
            smooth={true}
            duration={500}
            className={`github ${activeLink === 'experience' ? 'active' : ''}`}
            onSetActive={() => handleSetActive('experience')}
          >
            <SiMusicbrainz className="navicon" />Experience
          </ScrollLink>
        </li>
        <li>
          <ScrollLink
            to="projectlinks"
            smooth={true}
            duration={500}
            className={`github ${activeLink === 'projectlinks' ? 'active' : ''}`}
            onSetActive={() => handleSetActive('projectlinks')}
          >
            <RiLink className="navicon" />Project
          </ScrollLink>
        </li>
      </ul>
      </nav>
    </div>
  );
}

export default Manusidebar;
