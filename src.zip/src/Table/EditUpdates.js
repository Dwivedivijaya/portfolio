import React from 'react';
import '../home/Home.css';
import Tables from '../../Table/Tables';

function Home() {
return (
    <>
      <div className="appSectionindex">
        <Tables />
      </div>  
    </>
  );
}

export default Home;