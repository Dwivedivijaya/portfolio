import React, { useState, useEffect } from "react";
import { useNavigate } from 'react-router-dom';  // Import `useNavigate`
import '../loginpages/Login.css';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import { FaRegEyeSlash } from "react-icons/fa";
import { FaRegEye } from "react-icons/fa";
import { MdOutlineMailOutline } from "react-icons/md";
import { CiUser } from "react-icons/ci";
function Loginpages() {
    const initialValues = { username: "", email: "", password: "" };
    const [formValues, setFormValues] = useState(initialValues);
    const [formErrors, setFormErrors] = useState({});
    const [isSubmit, setIsSubmit] = useState(false);

    const navigate = useNavigate();  // Create `navigate` function to handle redirects

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormValues({ ...formValues, [name]: value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        setFormErrors(validate(formValues));
        setIsSubmit(true);
    };

    const validate = (values) => {
        const errors = {};
        const emailRegex = /^[^\$@]+@[^\$@]+\.[^\$@]{2,}$/i;
        const usernameRegex = /^[a-zA-Z0-9]+$/;

        if (!values.username) {
            errors.username = "Username is required!";
        } else if (!usernameRegex.test(values.username)) {
            errors.username = "Username must contain only letters and numbers!";
        }

        if (!values.email) {
            errors.email = "Email is required!";
        } else if (!emailRegex.test(values.email)) {
            errors.email = "This is not a valid email format!";
        }

        if (!values.password) {
            errors.password = "Password is required!";
        } else if (values.password.length < 4) {
            errors.password = "Password must be more than 4 characters";
        } else if (values.password.length > 16) {
            errors.password = "Password cannot be more than 16 characters";
        }

        return errors;
    };

    useEffect(() => {
        if (Object.keys(formErrors).length === 0 && isSubmit) {
            console.log('Form submitted successfully');
            setFormValues(initialValues); // Reset form values to initialValues
            navigate('/home'); // Navigate to the success page
        }
    }, [formErrors, isSubmit, navigate]); // Include navigate in dependencies

// show and hide password 
const [passwordVisible, setPasswordVisible] = useState(false);
const togglePasswordVisibility = () => {
    setPasswordVisible(prevState => !prevState);
  };


    return (
        <div className="loginspagesSection">
            <div className="loginsection">
                <h1 className="headerlogins">Login</h1>
                <div className="mainsSectionlogins">
                    <form className="formSection" onSubmit={handleSubmit}>
                        {Object.keys(formErrors).length === 0 && isSubmit ? (
                            <p className="conformssubmitted">Form submitted successfully!</p>
                        ) : (
                            <></>
                        )}

                        <Form.Group className="mb-1" controlId="username">
                            <Form.Label>Username<span className="star">*</span></Form.Label>
                            <div className="inputpassword">
                            <Form.Control
                                type="text"
                                placeholder="Enter username"
                                name="username"
                                value={formValues.username}
                                onChange={handleChange}
                            /><CiUser />
                            </div>
                            {formErrors.username && <p className="error">{formErrors.username}</p>}
                        </Form.Group>

                        <Form.Group className="mb-1" controlId="email">
                            <Form.Label>Email<span className="star">*</span></Form.Label>
                            <div className="inputpassword">
                            <Form.Control
                                type="email"
                                placeholder="Enter email"
                                name="email"
                                value={formValues.email}
                                onChange={handleChange}
                            /><MdOutlineMailOutline />
                            </div>
                            {formErrors.email && <p className="error">{formErrors.email}</p>}
                        </Form.Group>

                        <Form.Group className="mb-2 " controlId="password">
                            <Form.Label>Password<span className="star">*</span></Form.Label>
                            <div className="inputpassword">
                            <Form.Control
                                 type={passwordVisible ? "text" : "password"} // Toggle between text and password
                                 placeholder="Enter password"
                                 name="password"
                                 value={formValues.password}
                                 onChange={handleChange}
                            />
                         <span onClick={togglePasswordVisibility}>
                          {passwordVisible ? <FaRegEye /> : <FaRegEyeSlash />} 
                       </span>
                            </div>
                            {formErrors.password && <p className="error">{formErrors.password}</p>}
                        </Form.Group>

                        <Form.Group className="w-100 d-flex align-items-center justify-content-center" controlId="submit">
                            <Button variant="primary" type="submit" className="fbtn">
                                Submit
                            </Button>
                        </Form.Group>
                    </form>
                </div>
            </div>
        </div>
    );
}

export default Loginpages;
