import React from 'react'
import { MdArrowForwardIos } from "react-icons/md";
export default function Skills() {
  return (
    <>
         <section id="skills" className="Skills section ed">
            <div className="section-title aos-init aos-animate" data-aos="fade-up">
              <h2 className='skillsheaders'>Skills</h2>
            </div>
               <div className='rowSkills'>
              <div className="row">
                <div className="col-lg-7">
                  <ul className='mb-0 pb-0 left'>
                    <li><MdArrowForwardIos /><strong>Skills:</strong> <span> HTML5, HTML, CSS, CSS3, GitHub, Material UI</span></li>
                    <li><MdArrowForwardIos /><strong>Development Environment:</strong> <span> Eclipse, Sublime Text, Visual Studio.</span></li>
                    <li><MdArrowForwardIos /> <strong>Framework:</strong> <span> Bootstrap, Tailwind CSS</span></li>
                    <li className='mb-0 pb-0'><MdArrowForwardIos /><strong>Scripting:</strong> <span> JavaScript</span></li>

                  </ul>
                </div>
                <div class="col-lg-5 right">
                  <ul>
                    <li><MdArrowForwardIos /> <strong>Library:</strong> <span> Reacts,JQuery</span></li>
                    <li><MdArrowForwardIos /> <strong>CMS Tool:</strong> <span> WordPress</span></li>
                    <li><MdArrowForwardIos /> <strong>OS:</strong> <span> Windows 7,8,10,11.</span></li>
                    <li className='mb-0 pb-0'><MdArrowForwardIos /> <strong>Server:</strong> <span> windows server(cPanel), FileZilla, SVN</span></li>
                  </ul>
                </div>

              </div>

            </div>
          </section>
    </>
  )
}
