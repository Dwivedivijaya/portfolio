import React from 'react';
import '../home/Home.css';
import '../home/homeMedia.css'
import Manusidebar from './Manusidebar';
import About from '../about/About';
import Project from '../project/Project'; 
import Experience from '../experience/Experience';
import Skills from '../skills/Skills';
import Eduction from '../eduction/Eduction';
import Footer from '../footer/Footer';
function Home() {

  return (
    <>
      <div className='homePagesMains'>
        <Manusidebar />

        <main className="main appSectionindex">
        <section id="hero" className="hero section dark-background">
            <img src="https://img.freepik.com/free-vector/paper-style-dynamic-lines-background_23-2149008629.jpg" alt="" data-aos="fade-in" className="aos-init aos-animate" />

            <div className="container aos-init aos-animate" data-aos="fade-up" data-aos-delay="100">
              <h2>UI Developer</h2>
              <p>I'm <span className="typed" data-typed-items="UI Developer, Frontend Developer">Vijaya Dwivedi</span>
                <span className="typed-cursor" aria-hidden="true">|</span>
                <span className="typed-cursor typed-cursor--blink" aria-hidden="true"></span>
                <span className="typed-cursor typed-cursor--blink" aria-hidden="true"></span></p>
            </div>
          </section> 
          <section id="hero1" className="hero section dark-background mobileView">
            <img src="https://img.freepik.com/free-vector/paper-style-dynamic-lines-background_23-2149008629.jpg" alt="" data-aos="fade-in" className="aos-init aos-animate" />

            <div className="container aos-init aos-animate" data-aos="fade-up" data-aos-delay="100">
            <div class="profile-img"><img src="/static/media/profiles2.054e77031e163510cf45.jpeg" alt="Profile" class="img-fluid rounded-circle-images" /></div>
            <div class="profile-img-mobiles">
              <h2>Vijaya Dwivedi</h2>
              <p>I'm <span className="typed" data-typed-items="UI Developer, Frontend Developer">UI Developer</span>
                <span className="typed-cursor" aria-hidden="true">|</span>
                <span className="typed-cursor typed-cursor--blink" aria-hidden="true"></span>
                <span className="typed-cursor typed-cursor--blink" aria-hidden="true"></span></p>
            </div>
            </div>
          </section>
          <About />
         <Eduction />
          <Skills />
          <Experience />
           <Project />
           <Footer />
        </main>

      </div>

    </>
  );
}

export default Home;
