import React from 'react';
import babsafarImage from '../../assets/images/babsafarImage.png';
import imageseasy from '../../assets/images/imageseasy.png';
import iamgeslider from '../../assets/images/iamgeslider.jpg';
import topiamgesimages from '../../assets/images/topiamgesimages.jpg';
import images from '../../assets/images/images.jpg';
import { FaLinkSlash } from "react-icons/fa6";
import { Link } from 'react-router-dom';

export default function Project() {
  // Array to hold the project data
  const projects = [
    {
      image: topiamgesimages,
      link: "https://boookers.com/",
      alt: "Top Images",
    },
    {
      image: iamgeslider,
      link: "https://babsafar.com/",
      alt: "Images Slider",
    },
    {
      image: images,
      link: "https://q8by.com/",
      alt: "Q8 By",
    },
    {
      image: babsafarImage,
      link: "https://www.alghanimtravel.com/",
      alt: "Babsafar Image",
    },
    {
      image: imageseasy,
      link: "https://www.kuwaitairways.com/",
      alt: "Easy Image",
    },
  ];

  return (
    <>
      <section id="projectlinks" className="projectlinks section ed">
        <div className="section-title aos-init aos-animate" data-aos="fade-up">
          <h2 className='EducationAbouts'>Project Links</h2>
        </div>
        <div className="lightbox" data-mdb-lightbox-init>
          <div className="row">
            {projects.map((project, index) => (
              <div key={index} className={`col-lg-${index < 3 ? '4' : '6'} mt-4`}>
                <div className="container-iamges">
                  <img
                    src={project.image}
                    alt={project.alt}
                    className={`imagesslider${index < 3 ? '2' : '1'} w-100 shadow-1-strong rounded`}
                  />
                  <div
                    className="middle-images"
                    data-bs-toggle="tooltip"
                    data-bs-placement="bottom"
                    data-bs-dismiss="click"
                    data-bs-trigger="hover"
                    title="Open Project"
                  >
                    <Link to={project.link} className="textIcons">
                      <FaLinkSlash />
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
