import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { FaGithub } from "react-icons/fa6";
import { FaLinkedin } from "react-icons/fa6";
import { BiLogoNetlify } from "react-icons/bi";
export default function Footer() {
    const [currentDate, setCurrentDate] = useState(new Date());
    useEffect(() => {
        const intervalId = setInterval(() => {
          setCurrentDate(new Date());
        }, 1000); // Update every second
    
        return () => clearInterval(intervalId);
      }, []);
    return (
        <>
            <section id="footer" className="footer section ed">
                <div className='footersright'>
                    <p><strong className='pe-2'>Current Location:</strong>New Delhi</p>
                    <p><strong className='pe-2'>Date:</strong>{currentDate.toLocaleDateString()}</p>
                </div>
                <div className='footerslefts'><p className='usernamesa'>Vijaya Dwivedi</p>
                 <div className='connectionfooters'>
                    <h6>Social Connection</h6>
                      <div className="social-links">
                            <Link to="https://github.com/Dwivedivijaya/" className="github" data-bs-toggle="tooltip" data-bs-placement="bottom" title="github">
                              <FaGithub />
                            </Link>
                            <Link to="https://www.linkedin.com/in/immediate-joiner-vijaya-dwivedi-69a59b14a/" className="facebook" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Linkedin">
                              <FaLinkedin />
                            </Link>
                            <Link to="https://www.netlify.com/" className="instagram" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Netlify">
                              <BiLogoNetlify />
                            </Link>
                          </div>
                 </div>
                
                </div>
            </section>
        </>
    )
}
