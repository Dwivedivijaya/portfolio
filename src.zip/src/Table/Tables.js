import { useState, useEffect } from 'react';
import { MdDelete } from "react-icons/md";
import { FiEdit } from "react-icons/fi";
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import data from './data.json';
import { IoSearch } from "react-icons/io5";

function Tables() {
  const [users, setUsers] = useState([]); // All users data
  const [searchQuery, setSearchQuery] = useState(''); // Search query state
  const [filteredUsers, setFilteredUsers] = useState([]); // Filtered users based on search query

  // Initial data loading (this would be your actual data source)
  useEffect(() => {
    setUsers(data);
    setFilteredUsers(data); // Initially, show all users
  }, []);

  // Modal and user edit state management
  const [showModal, setShowModal] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [newName, setNewName] = useState('');
  const [newAge, setNewAge] = useState('');
  const [newHobby, setNewHobby] = useState('');

  // Handle modal open and set the user to be edited
  const handleShow = (user) => {
    setEditingUser(user);
    setNewName(user.name);
    setNewAge(user.age);
    setNewHobby(user.hobby);
    setShowModal(true); // Open modal
  };

  // Handle update user data
  const handleUpdate = () => {
    const updatedUsers = users.map(user =>
      user.id === editingUser.id
        ? { ...user, name: newName, age: newAge, hobby: newHobby }
        : user
    );
    setUsers(updatedUsers);
    setFilteredUsers(updatedUsers); // Update filtered users
    setShowModal(false); // Close modal
    setEditingUser(null); // Clear editing user
  };

  // Handle delete button click for individual user
  const handleDelete = (id) => {
    const updatedData = users.filter(empuser => empuser.id !== id);
    setUsers(updatedData);
    setFilteredUsers(updatedData); // Update filtered users after deletion
  };

  // Clear all users (delete all rows in the table)
  const tableDeleteHandle = () => {
    setUsers([]); 
    setFilteredUsers([]); // Clear filtered users
  };

  // Handle search input change and filter users
  const searchInputTables = (event) => {
    const query = event.target.value;
    setSearchQuery(query); // Update search query
    // Filter users based on the query (case insensitive search)
    const filtered = users.filter(user =>
      user.name.toLowerCase().includes(query.toLowerCase()) || 
      user.age.toString().includes(query) || 
      user.hobby.toLowerCase().includes(query.toLowerCase())
    );
    setFilteredUsers(filtered); // Update filtered users
  };

  return (
    <>
      <div className="appSectionindex11">
        <div className="mainSection">
          <div className='tablesflex d-flex align-items justify-content-end'>
            <div className='d-flex align-items gap-2'>
              <input 
                type="text" 
                className="form-control1" 
                placeholder='Search'  
                value={searchQuery} // Bind search query to input value
                onChange={searchInputTables} // Handle input change
              />
              <span className='btnsa'>
                <IoSearch />
              </span>
            </div>
            <span className='btnsa12'>
            <MdDelete onClick={tableDeleteHandle} />
            </span>
          </div> 

          {/* Table */}
          <table className="table table-bordered mt-2">
            <thead>
              <tr>
                <td style={{ padding: '7px', background: '#807d7d' }} className="fs-7 fw-bold text-white text-center">Sr.No</td>
                <td style={{ padding: '7px', background: '#807d7d' }} className="fs-7 fw-bold text-white text-center">Name</td>
                <td style={{ padding: '7px', background: '#807d7d' }} className="fs-7 fw-bold text-white text-center">Age</td>
                <td style={{ padding: '7px', background: '#807d7d' }} className="fs-7 fw-bold text-white text-center">Hobby</td>
                <td style={{ padding: '7px', background: '#807d7d' }} className="fs-7 fw-bold text-white text-center">Action</td>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.length > 0 ? (
                filteredUsers.map(empuser => (
                  <tr key={empuser.id}>
                    <td className="fs-7 fw-bold text-gray-300 text-center">{empuser.id}</td>
                    <td className="fs-7 fw-bold text-gray-300 text-center">{empuser.name}</td>
                    <td className="fs-7 fw-bold text-gray-300 text-center">{empuser.age}</td>
                    <td className="fs-7 fw-bold text-gray-300 text-center">{empuser.hobby}</td>
                    <td className="fs-7 fw-bold text-gray-300 text-center">
                    <span class="btnsa3"> <FiEdit onClick={() => handleShow(empuser)} /></span>
                    <span class="btnsa4"> <MdDelete onClick={() => handleDelete(empuser.id)} /></span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="5" className="text-center datanotFounts text-warning">No matching users found</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit Modal */}
      {showModal && (
        <Modal backdrop="static" show={showModal} onHide={() => setShowModal(false)}>
          <Modal.Header closeButton>
            <Modal.Title>Edit</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Form onSubmit={(e) => { e.preventDefault(); handleUpdate(); }}>
              <Form.Group className="mb-3" controlId="name">
                <Form.Label>Name</Form.Label>
                <input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="form-control"
                />
              </Form.Group>

              <Form.Group className="mb-3" controlId="age">
                <Form.Label>Age</Form.Label>
                <input
                  type="number"
                  value={newAge}
                  onChange={(e) => setNewAge(e.target.value)}
                  className="form-control"
                />
              </Form.Group>

              <Form.Group className="mb-3" controlId="hobby">
                <Form.Label>Hobby</Form.Label>
                <input
                  type="text"
                  value={newHobby}
                  onChange={(e) => setNewHobby(e.target.value)}
                  className="form-control"
                />
              </Form.Group>
            </Form>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={() => setShowModal(false)}>
              Close
            </Button>
            <Button variant="primary" onClick={handleUpdate}>
              Update
            </Button>
          </Modal.Footer>
        </Modal>
      )}
    </>
  );
}

export default Tables;
