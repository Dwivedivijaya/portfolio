import React from 'react';
import Profiles2 from '../../assets/images/profiles2.jpeg';
import { MdArrowForwardIos } from "react-icons/md";
export default function About() {
  return (
    <div className="">
   
             <section id="about" className="about section">
               <div className="section-title aos-init aos-animate" data-aos="fade-up">
                 <h2>About</h2>
                 <p className='mb-4'>As an Accomplished UI Developer with experience supporting engagement with Customers. Practiced expert
                   in HTML5, CSS3, JavaScript, Bootstrap, React, JQuery, Material UI and responsive websites. Passionate about
                   implementing scalable solutions. Efficient problem solver with skills in teamwork and delivering projects on
                   time.</p>
               </div>
   
               <div className="abouts1profiles" data-aos="fade-up" data-aos-delay="100">
   
                 <div className="justifycontentcenter">
                   <div className="profilesAbouts1">
                     <img src={Profiles2} className="img-fluid img-fluid-abouts" alt="" />
                   </div>
                   <div className="contentFrontend">
                     <h3>Personal Profile</h3>
                     <div className="row">
                       <div className="col-lg-6">
                         <ul>
                           <li><MdArrowForwardIos /><strong>Birthday:</strong> <span>3 July 1996</span></li>
                           <li><MdArrowForwardIos /><strong>Email:</strong> <span>dwivedivijaya371996@gmail.com</span></li>
                           <li><MdArrowForwardIos /> <strong>Phone:</strong> <span>9755289103</span></li>
                           <li><MdArrowForwardIos /><strong>Current Location:</strong> <span>New Delhi</span></li>
                         </ul>
                       </div>
                       <div class="col-lg-6">
                         <ul>
                           <li><MdArrowForwardIos /> <strong>Gender:</strong> <span>Female</span></li>
                           <li><MdArrowForwardIos /> <strong>Marital Status:</strong> <span>Single</span></li>
                           <li><MdArrowForwardIos /> <strong>Languages Known:</strong> <span>Hindi and English</span></li>
                           <li><MdArrowForwardIos /> <strong>Nationality:</strong> <span>Indian</span></li>
                         </ul>
                       </div>
                     </div>
   
                   </div>
                 </div>
   
               </div>
   
             </section>
    </div>
  );
}

